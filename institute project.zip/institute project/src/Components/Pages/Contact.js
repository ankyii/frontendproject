import React from "react";


function Contact(){
    return(
        <div className="Container">
            <div className="Card mt-4">
                <div className="Card-body">
                    <h2>Home Page</h2>
                </div>
            </div>
        </div>

    );

}

export default Contact;