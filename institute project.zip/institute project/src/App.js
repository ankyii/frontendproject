import React from'react';
import Home from './Components/Pages/Home';
import About from './Components/Pages/About';
import Contact from './Components/Pages/Contact';


function App() {
  return (
    <div>
      <Home/>
    </div>
  );
}

export default App;
